#pragma once

#include "Line.h"
#include "Scene.h"

bool liangBarsky(Line& line); // Line clipping