#include "Node3D.h"

Node3D::Node3D(){
    left = nullptr;
    right = nullptr;
}